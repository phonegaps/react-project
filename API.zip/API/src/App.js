import "./App.scss";
import Header from "./common/header/Header";
import SideNavigation from "./common/sideNavigation/SideNavigation";
import Footer from "./common/footer/Footer";
import { Container, Card } from "react-bootstrap";

// start redux
import { connect } from "react-redux";

function mapStateToProps(state) {
  return {
    currentUser: state.currentUser,
  };
}

function mapDispatchToProps(dispatch) {
  return {
    setUser: (userObject) => {
      dispatch({ type: "SET_USER", payload: userObject });
    },
  };
}

// end redux

function App() {
  return (
    <>
      <Header />
      <Container fluid>
        <div className="flex-xl-nowrap row">
          <SideNavigation />
          <main className="main-container">
            <Card>
              <Card.Header>
                <Card.Title>Home</Card.Title>
              </Card.Header>
              <Card.Body>
                <Card.Text>
                  Some quick example text to build on the card title and make up
                  the bulk of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>
          </main>
        </div>
      </Container>
      <Footer />
    </>
  );
}

export default connect(mapStateToProps, mapDispatchToProps)(App);
