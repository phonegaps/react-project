import './Customers.scss';
import Header from '../../common/header/Header';
import SideNavigation from '../../common/sideNavigation/SideNavigation';
import Footer from '../../common/footer/Footer';
import {Container} from "react-bootstrap";

function Customers() {
  return (
    <>
      <Header />
      <Container fluid>
        <div className="flex-xl-nowrap row">
          <SideNavigation />          
          <main className="main-container">
            <h3>Customers</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
          </main>
        </div>
      </Container>
      <Footer />      
    </>
  );
}

export default Customers;
