import "./Products.scss";
import { LinkContainer } from "react-router-bootstrap";
import Header from "../../common/header/Header";
import SideNavigation from "../../common/sideNavigation/SideNavigation";
import Footer from "../../common/footer/Footer";
import {
  Container,
  Card,
  Button,
  Row,
  Col,
  Form,
  InputGroup,
  FormControl,
  Dropdown,
} from "react-bootstrap";
import { BsArrowLeftSquare } from "react-icons/bs";
import { FaSearch, FaSort } from "react-icons/fa";
import DragNDrop from "../dragNDrop/DragNDrop";

function AddProduct() {
  return (
    <>
      <Header />
      <Container fluid>
        <div className="flex-xl-nowrap row">
          <SideNavigation />
          <main className="main-container">
            <Card className="page-title-container mb-2">
              <Card.Header>
                <Card.Title className="float-start mt-1">
                  <LinkContainer to="/products-list">
                    <Button variant="link" className="page-backlink">
                      <BsArrowLeftSquare className="BsArrowLeftSquare" /> Add
                      Product
                    </Button>
                  </LinkContainer>
                </Card.Title>
              </Card.Header>
            </Card>
            <Row>
              <Col md={9}>
                <Card className="p-3 pt-2">
                  <Card.Body>
                    <Form>
                      <Form.Group className="mb-3" controlId="">
                        <Form.Label>Title</Form.Label>
                        <Form.Control
                          type="text"
                          placeholder="Please Enter Product name"
                        />
                      </Form.Group>
                      <Form.Group
                        className=""
                        controlId="exampleForm.ControlTextarea1"
                      >
                        <Form.Label>Description</Form.Label>
                        <Form.Control
                          as="textarea"
                          rows={3}
                          placeholder="Please Enter dDescription"
                        />
                      </Form.Group>
                    </Form>
                  </Card.Body>
                </Card>

                <Card className="p-3 pt-2 mt-3">
                  <Card.Body>
                    <Card.Title className="mt-1 mb-3">
                      Media{" "}
                      <Button
                        variant="link"
                        className="float-end text-decoration-none btn-default pe-0"
                      >
                        Add Media from URL
                      </Button>
                    </Card.Title>
                    <DragNDrop />
                  </Card.Body>
                </Card>

                <Card className="p-3 pt-2 mt-3">
                  <Card.Title className="float-start mt-1 mb-3">
                    Pricing
                  </Card.Title>
                  <Card.Body>
                    <Form>
                      <Row>
                        <Col md={6}>
                          <Form.Group className="mb-3" controlId="">
                            <Form.Label>Price</Form.Label>
                            <InputGroup className="mb-3">
                              <InputGroup.Text id="basic-addon1">
                                $
                              </InputGroup.Text>
                              <FormControl placeholder="0.00" />
                            </InputGroup>
                          </Form.Group>
                        </Col>
                        <Col md={6}>
                          <Form.Group className="mb-3" controlId="">
                            <Form.Label>Compare at price</Form.Label>
                            <InputGroup className="mb-3">
                              <InputGroup.Text id="basic-addon1">
                                $
                              </InputGroup.Text>
                              <FormControl placeholder="0.00" />
                            </InputGroup>
                          </Form.Group>
                        </Col>
                      </Row>
                      <Form.Group className="mb-3" controlId="">
                        <Form.Label>Cost per item</Form.Label>
                        <InputGroup className="">
                          <InputGroup.Text id="basic-addon1">$</InputGroup.Text>
                          <FormControl placeholder="0.00" />
                        </InputGroup>
                        <Form.Text className="text-muted">
                          Customers won't see this
                        </Form.Text>
                      </Form.Group>
                      <Form.Group className="" controlId="">
                        <Form.Check
                          type="checkbox"
                          label="Charge tax on this product"
                        />
                      </Form.Group>
                    </Form>
                  </Card.Body>
                </Card>

                <Card className="p-3 pt-2 mt-3">
                  <Card.Title className="float-start mt-1 mb-3">
                    Inventory
                  </Card.Title>
                  <Card.Body>
                    <Form>
                      <Row>
                        <Col md={6}>
                          <Form.Group className="mb-3" controlId="">
                            <Form.Label>SKU (Stock Keeping Unit)</Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="Please Enter SKU"
                            />
                          </Form.Group>
                        </Col>
                        <Col md={6}>
                          <Form.Group className="mb-3" controlId="">
                            <Form.Label>
                              Barcode (ISBN, UPC, GTIN, etc.)
                            </Form.Label>
                            <Form.Control
                              type="text"
                              placeholder="Please Enter SKU"
                            />
                          </Form.Group>
                        </Col>
                      </Row>
                      <Form.Group className="" controlId="">
                        <Form.Check type="checkbox" label="Track quantity" />
                      </Form.Group>
                      <Form.Group className="" controlId="">
                        <Form.Check
                          type="checkbox"
                          label="Continue selling when out of stock"
                        />
                      </Form.Group>
                      <br />
                      <Form.Text className="fw-bold fs-6 ">QUANTITY</Form.Text>
                      <Form.Group className="mb-3 mt-2" controlId="">
                        <Form.Label>Available</Form.Label>
                        <Form.Control type="number" placeholder="0" />
                      </Form.Group>
                    </Form>
                  </Card.Body>
                </Card>

                <Card className="p-3 pt-2 mt-3">
                  <Card.Title className="float-start mt-1 mb-3">
                    Shipping
                  </Card.Title>
                  <Card.Body>
                    <Form>
                      <Form.Group className="mb-3" controlId="">
                        <Form.Check
                          type="checkbox"
                          label="This is physical product"
                        />
                      </Form.Group>
                      <Form.Text className="fw-bold fs-6 ">WEIGHT</Form.Text>
                      <br />
                      <Form.Text className="text-muted">
                        Used to calculate shipping rates at checkout and label
                        prices during fulfillment.
                      </Form.Text>
                      <Form.Group className="mt-3" controlId="">
                        <Form.Label>Weight</Form.Label>
                        <Row>
                          <Col md={6}>
                            <InputGroup className="mb-3">
                              <FormControl placeholder="0.00" />
                              <Form.Select>
                                <option>KG</option>
                                <option>KG</option>
                              </Form.Select>
                            </InputGroup>
                          </Col>
                        </Row>
                      </Form.Group>
                      <Form.Text className="fw-bold fs-6 ">
                        CUSTOMS INFORMATION
                      </Form.Text>
                      <br />
                      <Form.Text className="text-muted">
                        Customs authorities use this information to calculate
                        duties when shipping internationally. <br />
                        Shown on printed customsforms.
                      </Form.Text>
                      <Form.Group className="mt-3" controlId="">
                        <Form.Label>Country / Region of origin</Form.Label>
                        <Form.Select>
                          <option>Select Country / Region</option>
                          <option>India</option>
                        </Form.Select>
                        <Form.Text className="text-muted">
                          In most cases, where the product is manufactured.
                        </Form.Text>
                      </Form.Group>
                      <Form.Group className="mt-3" controlId="">
                        <Form.Label>HS (Harmonized System ) code</Form.Label>
                        <InputGroup className="">
                          <InputGroup.Text id="">
                            <FaSearch />
                          </InputGroup.Text>
                          <FormControl placeholder="Search or Enter a HS code" />
                        </InputGroup>
                        <Form.Text className="text-muted">
                          Manually enter codes that are longer than 6 numbers
                        </Form.Text>
                      </Form.Group>
                    </Form>
                  </Card.Body>
                </Card>

                <Card className="p-3 pt-2 mt-3">
                  <Card.Title className="float-start mt-1 mb-3">
                    Option
                  </Card.Title>
                  <Card.Body>
                    <Form>
                      <Form.Group className="" controlId="">
                        <Form.Check
                          type="checkbox"
                          label="This product has option, like size or color"
                        />
                      </Form.Group>
                    </Form>
                  </Card.Body>
                </Card>

                <Card className="p-3 pt-2 mt-3">
                  <Card.Title className="float-start mt-1 mb-3">
                    Search engine listing preview
                    <Button
                      variant="link"
                      className="float-end text-decoration-none btn-default pe-0"
                    >
                      Edit website SEO
                    </Button>
                  </Card.Title>
                  <Card.Body>
                    <Form.Text className="text-muted">
                      Add a title and description to see how this product migth
                      appear in a search engine listing
                    </Form.Text>
                  </Card.Body>
                </Card>
              </Col>
              <Col md={3}>
                <Card>
                  <Card.Title className="mt-2 me-3 ms-3 mb-3" as="h6">
                    Product Stutas
                  </Card.Title>
                  <Card.Body>
                    <Dropdown className="border m-3 mb-0 rounded draft">
                      <Dropdown.Toggle variant="link" id="dropdown-basic">
                        Draft <FaSort className="float-end mt-1" />
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item eventKey="1">Export</Dropdown.Item>
                        <Dropdown.Item eventKey="2">
                          Dropdown link
                        </Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                    <Form.Text className="text-muted m-3 mt-0">
                      Customers won't see this
                    </Form.Text>
                    <div className="border-top p-3 mt-3">
                      <p className="text-w500 mb-2">SALES CHANNELS AND APP</p>
                      <Button
                        variant="link"
                        className="text-decoration-none btn-default p-0 pb-1"
                      >
                        Deselect All
                      </Button>
                      <Form className="border-top mt-1">
                        <Form.Group
                          className="border-bottom pt-3 pb-3"
                          controlId=""
                        >
                          <Form.Check type="checkbox" label="Online Store" />
                          <Button
                            variant="link"
                            className="text-decoration-none btn-default p-0 pb-1 ms-3"
                          >
                            Schedule Availability
                          </Button>
                        </Form.Group>
                        <Form.Group
                          className="border-bottom pb-3 pt-3"
                          controlId=""
                        >
                          <Form.Check type="checkbox" label="Facebook" />
                          <p className="text-muted m-3 mt-0 ms-3">
                            Facebook is disconnected to keep your account
                            secure. Reconnect your Facebook account to run a
                            campaign
                          </p>
                          <Button
                            variant="link"
                            className="text-decoration-none btn-default p-0 pb-1 ms-3"
                          >
                            Learn more
                          </Button>
                        </Form.Group>
                        <Form.Group className="border-bottom pb-3 pt-3">
                          <Form.Check type="checkbox" label="Google" />
                        </Form.Group>
                        <Form.Group className="border-bottom pb-3 pt-3">
                          <Form.Check type="checkbox" label="Buy Button" />
                        </Form.Group>
                        <Form.Group className="border-bottom pb-3 pt-3">
                          <Form.Check
                            type="checkbox"
                            label="Microsoft Advertising"
                          />
                          <p className="text-muted m-3 mt-0 ms-3">
                            Microsoft Advertising is not ready. Setup your
                            account to use this app.
                          </p>
                          <Button
                            variant="link"
                            className="text-decoration-none btn-default p-0 pb-1 ms-3"
                          >
                            Learn more
                          </Button>
                        </Form.Group>
                        <Form.Group className="pt-3">
                          <Form.Check type="checkbox" label="Handshake" />
                        </Form.Group>
                      </Form>
                    </div>
                  </Card.Body>
                </Card>
                <Card className="mt-3 bg-2 border-color-1">
                  <Card.Title className="mt-2 me-3 ms-3" as="h6">
                    Organization
                  </Card.Title>
                  <Card.Body>
                    <Form>
                      <Form.Group className="p-3 mb-3 border-bottom">
                        <Form.Label>Vendor</Form.Label>
                        <InputGroup>
                          <FormControl placeholder="e.g Nike" />
                          <InputGroup.Text id="basic-addon2">
                            <FaSort />
                          </InputGroup.Text>
                        </InputGroup>
                      </Form.Group>
                      <Card.Title className="mt-2 me-3 ms-3" as="h6">
                        Product Type
                      </Card.Title>
                      <Form.Group className="p-3 mb-3 border-bottom">
                        <Form.Label>Vendor</Form.Label>
                        <InputGroup>
                          <FormControl placeholder="e.g Nike" />
                          <InputGroup.Text id="basic-addon2">
                            <FaSort />
                          </InputGroup.Text>
                        </InputGroup>
                      </Form.Group>
                    </Form>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </main>
        </div>
      </Container>
      <Footer />
    </>
  );
}

export default AddProduct;
