import "./Products.scss";
import { LinkContainer } from "react-router-bootstrap";
import Header from "../../common/header/Header";
import SideNavigation from "../../common/sideNavigation/SideNavigation";
import Footer from "../../common/footer/Footer";
import {
  Container,
  Card,
  ButtonGroup,
  Button,
  DropdownButton,
  Dropdown,
  Modal,
  Form,
  Table,
  Figure,
  Badge,
  Pagination,
} from "react-bootstrap";
import React from "react";
import Filters from "../filters/Filters";

class Products extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isExportToggle: false,
      isImportToggle: false,
    };
  }

  componentDidMount() {
    console.log(this.props.store);
  }

  exportOpenButton() {
    this.setState({
      isExportToggle: !this.state.isExportToggle,
    });
  }
  importOpenButton() {
    this.setState({
      isImportToggle: !this.state.isImportToggle,
    });
  }

  render() {
    return (
      <>
        <Header />
        <Container fluid>
          <div className="flex-xl-nowrap row">
            <SideNavigation />
            <main className="main-container">
              <Card className="page-title-container mb-2">
                <Card.Header>
                  <Card.Title className="float-start mt-1">Products</Card.Title>
                  <ButtonGroup className="float-end p_button_group" size="sm">
                    <Button
                      variant="link"
                      onClick={() => {
                        this.exportOpenButton();
                      }}
                    >
                      Export
                    </Button>
                    <Button
                      variant="link"
                      onClick={() => {
                        this.importOpenButton();
                      }}
                    >
                      Import
                    </Button>
                    <DropdownButton
                      as={ButtonGroup}
                      title="More Action"
                      variant="link"
                      size="sm"
                    >
                      <Dropdown.Item eventKey="1" size="sm">
                        Export
                      </Dropdown.Item>
                      <Dropdown.Item eventKey="2" size="sm">
                        Dropdown link
                      </Dropdown.Item>
                    </DropdownButton>
                    <LinkContainer to="/addProduct">
                      <Button variant="success">Add Product</Button>
                    </LinkContainer>
                  </ButtonGroup>
                </Card.Header>
              </Card>

              <Modal
                show={this.state.isExportToggle}
                onHide={() => this.exportOpenButton()}
                backdrop="static"
                aria-labelledby="contained-modal-title-vcenter"
                centered
              >
                <Modal.Header closeButton>Export Products</Modal.Header>
                <Modal.Body className="p-0 pt-3 pb-3">
                  <p className="text-start ms-3 me-3">
                    This CSV file can update all product informatin. To update
                    just inventory quantities use the{" "}
                    <Button variant="link">CSV filefor inventory</Button>
                  </p>
                  <Form className="ms-3 me-3">
                    <Form.Group className="mb-3">
                      <Form.Label>Export</Form.Label>
                      <Form.Check type="radio" label="Current page" />
                      <Form.Check type="radio" label="All products" />
                      <Form.Check
                        type="radio"
                        label="Selected : 0 products"
                        disabled
                      />
                      <Form.Check
                        type="radio"
                        label="50+ products matching your search"
                        disabled
                      />
                    </Form.Group>
                    <Form.Group>
                      <Form.Label>Export as</Form.Label>
                      <Form.Check
                        type="radio"
                        label="CSV for Excel, Number or other spreadsheet programs"
                      />
                      <Form.Check type="radio" label="Plain CSV file" />
                    </Form.Group>
                  </Form>
                  <div className="border-top p-3 mt-3 pb-0 text-center">
                    Learn more about <Button variant="link">exporting</Button>,{" "}
                    <Button variant="link">products to CSV file</Button> or the{" "}
                    <Button variant="link">bulk editor</Button>.
                  </div>
                </Modal.Body>
                <Modal.Footer>
                  <Button
                    variant="link"
                    onClick={() => {
                      this.exportOpenButton();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button variant="success">Export Products</Button>
                </Modal.Footer>
              </Modal>

              <Modal
                show={this.state.isImportToggle}
                onHide={() => this.importOpenButton()}
                backdrop="static"
                aria-labelledby="contained-modal-title-vcenter"
                centered
              >
                <Modal.Header closeButton>Import products by CSV</Modal.Header>
                <Modal.Body className="p-0 pt-3 pb-3">
                  <p className="text-start ms-3 me-3">
                    Dowanload a{" "}
                    <Button variant="link">
                      sample CSV template to see an example of the format
                      required
                    </Button>
                  </p>
                  <Form className="ms-3 me-3">
                    <Form.Check
                      type="checkbox"
                      label="Overwrite any current products that have the same handle. Existing values will be used for any missing columns."
                    />
                    <Button variant="link">Learn more</Button>
                  </Form>
                </Modal.Body>
                <Modal.Footer>
                  <Button
                    variant="link"
                    onClick={() => {
                      this.importOpenButton();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button variant="success" disabled>
                    Upload and Continue
                  </Button>
                </Modal.Footer>
              </Modal>

              <Card>
                <Card.Header className="page-tab-section">
                  <ButtonGroup className="" size="sm">
                    <Button variant="link" className="active">
                      All
                    </Button>
                    <Button variant="link">Active</Button>
                    <Button variant="link">Draft</Button>
                    <Button variant="link">Archived</Button>
                  </ButtonGroup>
                </Card.Header>
                <Card.Body>
                  <Filters />
                  <div className="tableContent">
                    <Table hover responsive="sm">
                      <thead>
                        <tr>
                          <th className="tableHead">
                            <Form.Check type="checkbox" className="ms-2" />
                          </th>
                          <th className="tableHead">Product</th>
                          <th className="tableHead">Status</th>
                          <th className="tableHead">Inventory</th>
                          <th className="tableHead">Type</th>
                          <th className="tableHead">Vendor</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product1.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              3
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product1.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              7
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product1.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              4
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product1.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              8
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product1.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              2
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product2.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              2
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product3.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              3
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                        <tr>
                          <td>
                            <Form.Check type="checkbox" className="ms-2" />
                          </td>
                          <td>
                            <Figure>
                              <Figure.Image
                                src="/assets/img/product4.png"
                                rounded
                              />
                              <Figure.Caption>
                                Nulla vitae elit libero.
                              </Figure.Caption>
                            </Figure>
                          </td>
                          <td>
                            <Badge pill bg="info">
                              Active
                            </Badge>
                          </td>
                          <td>
                            <Badge bg="warning" text="dark me-2">
                              1
                            </Badge>
                            in stock
                          </td>
                          <td>Trays</td>
                          <td>erda.co.nz</td>
                        </tr>
                      </tbody>
                    </Table>
                    <div className="pagination-container">
                      <Pagination>
                        <Pagination.First />
                        <Pagination.Prev />
                        <Pagination.Item>{1}</Pagination.Item>
                        <Pagination.Item active>{2}</Pagination.Item>
                        <Pagination.Item>{3}</Pagination.Item>
                        <Pagination.Next />
                        <Pagination.Last />
                      </Pagination>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </main>
          </div>
        </Container>
        <Footer />
      </>
    );
  }
}

export default Products;
