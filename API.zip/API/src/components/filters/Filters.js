import './Filters.scss';
import {InputGroup, FormControl, DropdownButton, Dropdown, Button, Form} from "react-bootstrap";
import {FaSearch, FaStar, FaSort} from "react-icons/fa";

function Filters() {
    return (
      <>
            <div className="filters">
                <InputGroup className="p-3">
                    <InputGroup.Text><FaSearch /></InputGroup.Text>
                    <FormControl className="searchField" />
                    <DropdownButton variant="link productVendor" title="Product vendor">
                        <Dropdown.Item eventKey="1" size="sm">
                            <Form.Group className="" id="">
                                <Form.Check type="radio" label="Shaving Brush" />
                            </Form.Group>
                        </Dropdown.Item>
                        <Dropdown.Item eventKey="2" size="sm">
                            <Form.Group className="" id="">
                                <Form.Check type="radio" label="erda.co.nz" />
                            </Form.Group>                            
                        </Dropdown.Item>
                        <Dropdown.Item eventKey="2" size="sm">
                            <Form.Group className="" id="">
                                <Form.Check type="radio" label="wrapin" />
                            </Form.Group>                            
                        </Dropdown.Item>
                        <Dropdown.Item>
                        <Form.Text className="text-muted">Clear</Form.Text>
                        </Dropdown.Item>
                    </DropdownButton>
                    <DropdownButton variant="link toggledWith" title="Toggled with">
                        <Dropdown.Item eventKey="1" size="sm">
                        <Form.Control />
                        </Dropdown.Item>
                        <Dropdown.Item eventKey="2" size="sm">
                            <Form.Text className="text-muted">Clear</Form.Text>
                        </Dropdown.Item>
                    </DropdownButton>
                    <DropdownButton variant="link filterMore" title="Filter more">
                        <Dropdown.Item eventKey="1" size="sm">Export</Dropdown.Item>
                        <Dropdown.Item eventKey="2" size="sm">Dropdown link</Dropdown.Item>
                    </DropdownButton>
                    <Button variant="link save" disabled><FaStar /> Save</Button>
                    <Dropdown>
                        <Dropdown.Toggle variant="link sort" id="dropdown-basic">
                            <FaSort /> Sort
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                            <Dropdown.Item eventKey="2" size="sm">
                                <Form.Text className="text-muted">Sort By</Form.Text>
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Product title A - Z" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Product title Z - A" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Created (Oldest first)" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Created (Newest first)" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Updated (Oldest first)" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Updated (Newest first)" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="Low inventory" />
                                </Form.Group> 
                            </Dropdown.Item>
                            <Dropdown.Item>
                                <Form.Group className="" id="">
                                    <Form.Check type="radio" label="High inventory" />
                                </Form.Group> 
                            </Dropdown.Item>
                        </Dropdown.Menu>
                    </Dropdown>
                </InputGroup>
            </div>
      </>
    );
}
  
export default Filters;