import './Analytics.scss';
import Header from '../../common/header/Header';
import SideNavigation from '../../common/sideNavigation/SideNavigation';
import Footer from '../../common/footer/Footer';
import {Container, Card} from "react-bootstrap";

function Analytics() {
  return (
    <>
      <Header />
      <Container fluid>
        <div className="flex-xl-nowrap row">
          <SideNavigation />          
          <main className="main-container">
            <Card>
              <Card.Header><Card.Title>Analytics</Card.Title></Card.Header>
              <Card.Body>                
                <Card.Text>
                  Some quick example text to build on the card title and make up the bulk
                  of the card's content.
                </Card.Text>
              </Card.Body>
            </Card>    
          </main>
        </div>
      </Container>
      <Footer />      
    </>
  );
}

export default Analytics;
