import "./DragNDrop.scss";

import { Image, Button } from "react-bootstrap";
import { FaUpload } from "react-icons/fa";
import React, { useState, useEffect, open } from "react";
import { useDropzone } from "react-dropzone";

function DragNDrop() {
  const thumbsContainer = {
    display: "flex",
    flexDirection: "row",
    flexWrap: "wrap",
  };

  const thumb = {
    display: "inline-flex",
    borderRadius: 2,
    border: "1px solid #eaeaea",
    marginBottom: 8,
    marginRight: 8,
    width: 100,
    height: 100,
    padding: 4,
    boxSizing: "border-box",
  };

  const thumbInner = {
    display: "flex",
    minWidth: 0,
    overflow: "hidden",
  };

  const img = {
    display: "block",
    width: "auto",
    height: "100%",
  };

  const [files, setFiles] = useState([]);
  const { getRootProps, getInputProps } = useDropzone({
    accept: "image/*",
    onDrop: (acceptedFiles) => {
      setFiles(
        acceptedFiles.map((file) =>
          Object.assign(file, {
            preview: URL.createObjectURL(file),
          })
        )
      );
    },
  });

  const thumbs = files.map((file) => (
    <div style={thumb} key={file.name}>
      <div style={thumbInner}>
        <Image src={file.preview} style={img} />
      </div>
    </div>
  ));

  useEffect(
    () => () => {
      // Make sure to revoke the data uris to avoid memory leaks
      files.forEach((file) => URL.revokeObjectURL(file.preview));
    },
    [files]
  );

  return (
    <>
      <section className="dragNDrop">
        <div {...getRootProps({ className: "dropzone" })}>
          <input {...getInputProps()} />
          <FaUpload className="FaUpload" />
          <p>Drag 'n' drop some files here, or click to select files</p>
          <Button variant="link border" onClick={open}>
            Open File Dialog
          </Button>
        </div>
        <aside style={thumbsContainer}>{thumbs}</aside>
      </section>
    </>
  );
}

export default DragNDrop;
