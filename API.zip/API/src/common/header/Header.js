import "./header.scss";

import {
  Container,
  InputGroup,
  FormControl,
  Navbar,
  Nav,
  NavDropdown,
  Offcanvas,
  Accordion,
} from "react-bootstrap";
import { FaUserCircle, FaSearch } from "react-icons/fa";
import { LinkContainer } from "react-router-bootstrap";
import { FcHome } from "react-icons/fc";
import { FaFileDownload, FaDisease } from "react-icons/fa";
import {
  BsFillMegaphoneFill,
  BsFillPersonFill,
  BsBarChartLineFill,
} from "react-icons/bs";
import { AiFillTag, AiOutlineAppstoreAdd } from "react-icons/ai";

function Header() {
  return (
    <header className="fixed-top topHead">
      <Container fluid>
        <Navbar bg="light" collapseOnSelect expand="lg">
          <Navbar.Toggle aria-controls="offcanvasNavbar" />
          <Navbar.Brand href="/">ERDA</Navbar.Brand>
          <nav className="navTop">
            <InputGroup className="searchField">
              <InputGroup.Text id="basic-addon1">
                <FaSearch />
              </InputGroup.Text>
              <FormControl />
            </InputGroup>
            <div className="userDetails">
              <FaUserCircle className="userIcon" />{" "}
              <span className="userName">Abbas Munshi</span>
            </div>
          </nav>
          <Navbar.Offcanvas
            id="offcanvasNavbar"
            aria-labelledby="offcanvasNavbarLabel"
            placement="start"
          >
            <Offcanvas.Header closeButton>
              <Offcanvas.Title id="offcanvasNavbarLabel">ERDA</Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body>
              <Nav className="justify-content-end flex-grow-1">
                <Accordion>
                  <LinkContainer to="/">
                    <Nav.Link>
                      {" "}
                      <FcHome /> Home
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="/orders">
                    <Nav.Link>
                      <FaFileDownload /> Order
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="/products-list">
                    <Nav.Link>
                      <AiFillTag /> Product
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="/customers">
                    <Nav.Link>
                      <BsFillPersonFill /> Customers
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="/analytics">
                    <Nav.Link>
                      <BsBarChartLineFill /> Analytics
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="#">
                    <Nav.Link>
                      <BsFillMegaphoneFill /> Marketing
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="#">
                    <Nav.Link>
                      <FaDisease /> Discounts
                    </Nav.Link>
                  </LinkContainer>
                  <LinkContainer to="#">
                    <Nav.Link>
                      <AiOutlineAppstoreAdd /> App
                    </Nav.Link>
                  </LinkContainer>
                  <Nav.Link eventKey="disabled" disabled>
                    SALES CHANNELS
                  </Nav.Link>
                  <NavDropdown title="Dropdown" id="offcanvasNavbarDropdown">
                    <NavDropdown.Item href="#action3">Action</NavDropdown.Item>
                    <NavDropdown.Item href="#action4">
                      Another action
                    </NavDropdown.Item>
                    <NavDropdown.Divider />
                    <NavDropdown.Item href="#action5">
                      Something else here
                    </NavDropdown.Item>
                  </NavDropdown>
                </Accordion>
              </Nav>
            </Offcanvas.Body>
          </Navbar.Offcanvas>
        </Navbar>
      </Container>
    </header>
  );
}

export default Header;
