import "./sideNavigation.scss";

import { Nav, Accordion } from "react-bootstrap";
import { LinkContainer } from "react-router-bootstrap";
import { FcHome } from "react-icons/fc";
import { FaFileDownload, FaDisease } from "react-icons/fa";
import {
  BsFillMegaphoneFill,
  BsFillPersonFill,
  BsBarChartLineFill,
} from "react-icons/bs";
import { AiFillTag, AiOutlineAppstoreAdd } from "react-icons/ai";

function SideNavigation() {
  return (
    <div className="sideBar">
      <Nav defaultActiveKey="/" className="flex-column">
        <Accordion>
          <LinkContainer to="/">
            <Nav.Link>
              {" "}
              <FcHome /> Home
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="/User">
            <Nav.Link>
              <FaFileDownload /> User
            </Nav.Link>
          </LinkContainer>
          <Accordion.Item eventKey="0">
            <Accordion.Header>
              <AiFillTag /> Products
            </Accordion.Header>
            <Accordion.Body>
              <LinkContainer to="/products-list">
                <Nav.Link>All Product</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/products-list">
                <Nav.Link>Inventory</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/products-list" disabled>
                <Nav.Link>Transfers</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/products-list">
                <Nav.Link>Collections</Nav.Link>
              </LinkContainer>
              <LinkContainer to="/products-list">
                <Nav.Link>Gift cards</Nav.Link>
              </LinkContainer>
            </Accordion.Body>
          </Accordion.Item>
          <LinkContainer to="/customers">
            <Nav.Link>
              <BsFillPersonFill /> Customers
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="/analytics">
            <Nav.Link>
              <BsBarChartLineFill /> Analytics
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="#">
            <Nav.Link>
              <BsFillMegaphoneFill /> Marketing
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="#">
            <Nav.Link>
              <FaDisease /> Discounts
            </Nav.Link>
          </LinkContainer>
          <LinkContainer to="#">
            <Nav.Link>
              <AiOutlineAppstoreAdd /> App
            </Nav.Link>
          </LinkContainer>
          <Nav.Link eventKey="disabled" disabled>
            SALES CHANNELS
          </Nav.Link>
        </Accordion>
      </Nav>
    </div>
  );
}

export default SideNavigation;
